#!/bin/bash
g++ -o ./part1SATInput ./part1SATInput.cpp
g++ -o ./part1GraphReconstruct ./part1GraphReconstruct.cpp
g++ -o ./maxClique ./maxClique.cpp
