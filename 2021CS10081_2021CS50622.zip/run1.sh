#!/bin/bash
./part1SATInput $1