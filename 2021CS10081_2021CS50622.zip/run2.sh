#!/bin/bash
./part1GraphReconstruct $1