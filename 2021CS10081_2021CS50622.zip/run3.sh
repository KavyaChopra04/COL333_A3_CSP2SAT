#!/bin/bash
./maxClique $1